<?php
// +----------------------------------------------------------------------
// | ThinkCMF [ WE CAN DO IT MORE SIMPLE ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013-2017 http://www.thinkcmf.com All rights reserved.
// +----------------------------------------------------------------------
// | Author: Dean <zxxjjforever@163.com>
// +----------------------------------------------------------------------
// API 模板文件，可以复制
namespace api\home\controller;

use cmf\controller\RestBaseController;

class RestController extends RestBaseController
{
    /**
     * 显示资源列表
     */
    public function index()
    {
    }

    /**
     * 保存新建的资源
     */
    public function save()
    {
    }

    /**
     * 显示指定的资源
     *
     * @param  int $id
     */
    public function read($id)
    {
    }

    /**
     * 保存更新的资源
     *
     * @param  int $id
     */
    public function update($id)
    {
    }

    /**
     * 删除指定资源
     *
     * @param  int $id
     */
    public function delete($id)
    {
    }

}
