<?php

use think\Route;

Route::resource('home/slides', 'home/Slides');